<?php
/**
 * @Author: ducnvtt
 * @Date:   2016-01-29 11:57:59
 * @Last Modified by:   ducnvtt
 * @Last Modified time: 2016-02-25 08:52:17
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
