<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$field['selected'] = $field['std'];
hb_dropdown_countries( $field );
?>
